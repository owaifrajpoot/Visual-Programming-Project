﻿using System;
using System.Data;
using System.Windows;
using Microsoft.Data.SqlClient;

namespace project_practice
{
    public partial class ProductForm : Window
    {
        private readonly string connectionString;

        public ProductForm()
        {
            InitializeComponent();
            connectionString = @"Data Source=DESKTOP-14CFJQK\SQLEXPRESS; Initial Catalog=INVENTORY_MANAGEMENT_SYSTEM; Integrated Security=True; TrustServerCertificate=True";
            LoadProductData();
        }

        private void LoadProductData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Name, SKU, Category, Quantity, UnitPrice, Barcode FROM Products";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    ProductDataGrid.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddProductButton_Click(object sender, RoutedEventArgs e)
        {
            NameTextBox.Clear();
            SKUTextBox.Clear();
            CategoryTextBox.Clear();
            QuantityTextBox.Clear();
            UnitPriceTextBox.Clear();
            BarcodeTextBox.Clear();
            MessageBox.Show("Ready to add a new product.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void EditProductButton_Click(object sender, RoutedEventArgs e)
        {
            if (ProductDataGrid.SelectedItem is DataRowView selectedRow)
            {
                NameTextBox.Text = selectedRow["Name"].ToString();
                SKUTextBox.Text = selectedRow["SKU"].ToString();
                CategoryTextBox.Text = selectedRow["Category"].ToString();
                QuantityTextBox.Text = selectedRow["Quantity"].ToString();
                UnitPriceTextBox.Text = selectedRow["UnitPrice"].ToString();
                BarcodeTextBox.Text = selectedRow["Barcode"].ToString();
            }
            else
            {
                MessageBox.Show("Please select a product to edit.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteProductButton_Click(object sender, RoutedEventArgs e)
        {
            if (ProductDataGrid.SelectedItem is DataRowView selectedRow)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM Products WHERE SKU = @SKU";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@SKU", selectedRow["SKU"].ToString());
                        command.ExecuteNonQuery();
                        MessageBox.Show("Product deleted successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadProductData();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting product: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a product to delete.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(NameTextBox.Text) ||
                string.IsNullOrWhiteSpace(SKUTextBox.Text) ||
                string.IsNullOrWhiteSpace(QuantityTextBox.Text) ||
                string.IsNullOrWhiteSpace(UnitPriceTextBox.Text))
            {
                MessageBox.Show("Please fill all required fields.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string skuCheckQuery = "SELECT COUNT(*) FROM Products WHERE SKU = @SKU";
                    SqlCommand skuCheckCommand = new SqlCommand(skuCheckQuery, connection);
                    skuCheckCommand.Parameters.AddWithValue("@SKU", SKUTextBox.Text);
                    int skuCount = (int)skuCheckCommand.ExecuteScalar();

                    string query;

                    if (skuCount > 0)
                    {
                        query = @"UPDATE Products 
                                  SET Name = @Name, Category = @Category, Quantity = @Quantity, UnitPrice = @UnitPrice, Barcode = @Barcode 
                                  WHERE SKU = @SKU";
                    }
                    else
                    {
                        query = @"INSERT INTO Products (Name, SKU, Category, Quantity, UnitPrice, Barcode) 
                                  VALUES (@Name, @SKU, @Category, @Quantity, @UnitPrice, @Barcode)";
                    }

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Name", NameTextBox.Text);
                    command.Parameters.AddWithValue("@SKU", SKUTextBox.Text);
                    command.Parameters.AddWithValue("@Category", string.IsNullOrWhiteSpace(CategoryTextBox.Text) ? DBNull.Value : CategoryTextBox.Text);
                    command.Parameters.AddWithValue("@Quantity", int.Parse(QuantityTextBox.Text));
                    command.Parameters.AddWithValue("@UnitPrice", decimal.Parse(UnitPriceTextBox.Text));
                    command.Parameters.AddWithValue("@Barcode", string.IsNullOrWhiteSpace(BarcodeTextBox.Text) ? DBNull.Value : BarcodeTextBox.Text);
                    command.ExecuteNonQuery();

                    MessageBox.Show("Product saved successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadProductData();
                }
            }
            catch (SqlException ex) when (ex.Number == 2627)
            {
                MessageBox.Show("The SKU already exists. Please use a unique SKU.", "Duplicate SKU Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving product: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            NameTextBox.Clear();
            SKUTextBox.Clear();
            CategoryTextBox.Clear();
            QuantityTextBox.Clear();
            UnitPriceTextBox.Clear();
            BarcodeTextBox.Clear();
            MessageBox.Show("Operation canceled.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void BackToDashboard_Click(object sender, RoutedEventArgs e)
        {
            DashboardWindow dashboard = new DashboardWindow();
            dashboard.Show();
            this.Close();
        }
    }
}
