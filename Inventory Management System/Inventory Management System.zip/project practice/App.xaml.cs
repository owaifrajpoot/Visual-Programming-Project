﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace project_practice
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
