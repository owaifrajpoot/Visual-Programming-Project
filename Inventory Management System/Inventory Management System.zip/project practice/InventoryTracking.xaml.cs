﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace project_practice
{
    public partial class InventoryTracking : Window
    {
        private readonly string connectionString;

        public InventoryTracking()
        {
            InitializeComponent();
            connectionString = @"Data Source=DESKTOP-14CFJQK\SQLEXPRESS; Initial Catalog=INVENTORY_MANAGEMENT_SYSTEM; Integrated Security=True; TrustServerCertificate=True";
            LoadStockMovementHistory();
        }

        private void LoadStockMovementHistory()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT MovementID, ProductID, MovementType, Quantity, MovementDate, Description FROM StockMovements";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    StockMovementDataGrid.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading stock movements: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddMovementButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(ProductIDTextBox.Text) || MovementTypeComboBox.SelectedItem == null ||
                string.IsNullOrWhiteSpace(QuantityTextBox.Text))
            {
                MessageBox.Show("Please fill all required fields.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO StockMovements (ProductID, MovementType, Quantity, Description) " +
                                   "VALUES (@ProductID, @MovementType, @Quantity, @Description)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@ProductID", int.Parse(ProductIDTextBox.Text));
                    command.Parameters.AddWithValue("@MovementType", (MovementTypeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString());
                    command.Parameters.AddWithValue("@Quantity", int.Parse(QuantityTextBox.Text));
                    command.Parameters.AddWithValue("@Description", string.IsNullOrWhiteSpace(DescriptionTextBox.Text) ? DBNull.Value : DescriptionTextBox.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Stock movement added successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadStockMovementHistory();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding stock movement: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshMovementsButton_Click(object sender, RoutedEventArgs e)
        {
            LoadStockMovementHistory();
        }

        private void ExportLogButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Export functionality will be implemented here.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void GoToDashboardButton_Click(object sender, RoutedEventArgs e)
        {
            DashboardWindow dashboard = new DashboardWindow();
            dashboard.Show();
            this.Close();
        }
    }
}
