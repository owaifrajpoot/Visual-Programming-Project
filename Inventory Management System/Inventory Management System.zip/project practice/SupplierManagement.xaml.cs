﻿using System;
using System.Data;
using System.Windows;
using Microsoft.Data.SqlClient;

namespace project_practice
{
    public partial class SupplierManagement : Window
    {
        private readonly string connectionString;

        public SupplierManagement()
        {
            InitializeComponent();
            connectionString = @"Data Source=DESKTOP-14CFJQK\SQLEXPRESS; Initial Catalog=INVENTORY_MANAGEMENT_SYSTEM; Integrated Security=True; TrustServerCertificate=True";
            LoadSuppliers();
        }

        private void LoadSuppliers()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT SupplierID, SupplierName, ContactName, Phone, Email, Address FROM Suppliers";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    SupplierDataGrid.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading suppliers: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddSupplierButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(SupplierNameTextBox.Text))
            {
                MessageBox.Show("Supplier Name is required.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Suppliers (SupplierName, ContactName, Phone, Email, Address) " +
                                   "VALUES (@SupplierName, @ContactName, @Phone, @Email, @Address)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@SupplierName", SupplierNameTextBox.Text);
                    command.Parameters.AddWithValue("@ContactName", string.IsNullOrWhiteSpace(ContactNameTextBox.Text) ? DBNull.Value : ContactNameTextBox.Text);
                    command.Parameters.AddWithValue("@Phone", string.IsNullOrWhiteSpace(PhoneTextBox.Text) ? DBNull.Value : PhoneTextBox.Text);
                    command.Parameters.AddWithValue("@Email", string.IsNullOrWhiteSpace(EmailTextBox.Text) ? DBNull.Value : EmailTextBox.Text);
                    command.Parameters.AddWithValue("@Address", string.IsNullOrWhiteSpace(AddressTextBox.Text) ? DBNull.Value : AddressTextBox.Text);
                    command.ExecuteNonQuery();
                    MessageBox.Show("Supplier added successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadSuppliers();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding supplier: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateSupplierButton_Click(object sender, RoutedEventArgs e)
        {
            if (SupplierDataGrid.SelectedItem is DataRowView selectedRow)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "UPDATE Suppliers SET SupplierName = @SupplierName, ContactName = @ContactName, " +
                                       "Phone = @Phone, Email = @Email, Address = @Address WHERE SupplierID = @SupplierID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@SupplierID", selectedRow["SupplierID"]);
                        command.Parameters.AddWithValue("@SupplierName", SupplierNameTextBox.Text);
                        command.Parameters.AddWithValue("@ContactName", string.IsNullOrWhiteSpace(ContactNameTextBox.Text) ? DBNull.Value : ContactNameTextBox.Text);
                        command.Parameters.AddWithValue("@Phone", string.IsNullOrWhiteSpace(PhoneTextBox.Text) ? DBNull.Value : PhoneTextBox.Text);
                        command.Parameters.AddWithValue("@Email", string.IsNullOrWhiteSpace(EmailTextBox.Text) ? DBNull.Value : EmailTextBox.Text);
                        command.Parameters.AddWithValue("@Address", string.IsNullOrWhiteSpace(AddressTextBox.Text) ? DBNull.Value : AddressTextBox.Text);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Supplier updated successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadSuppliers();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error updating supplier: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a supplier to update.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteSupplierButton_Click(object sender, RoutedEventArgs e)
        {
            if (SupplierDataGrid.SelectedItem is DataRowView selectedRow)
            {
                try
                {
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM Suppliers WHERE SupplierID = @SupplierID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@SupplierID", selectedRow["SupplierID"]);
                        command.ExecuteNonQuery();
                        MessageBox.Show("Supplier deleted successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                        LoadSuppliers();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting supplier: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("Please select a supplier to delete.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void RefreshSuppliersButton_Click(object sender, RoutedEventArgs e)
        {
            LoadSuppliers();
        }

        private void GoToDashboardButton_Click(object sender, RoutedEventArgs e)
        {
            DashboardWindow dashboard = new DashboardWindow();
            dashboard.Show();
            this.Close();
        }
    }
}
