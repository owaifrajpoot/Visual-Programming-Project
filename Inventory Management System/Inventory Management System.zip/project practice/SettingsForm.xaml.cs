﻿using System.IO;
using System.Windows;

namespace project_practice
{
    public partial class SettingsForm : Window
    {
        private static readonly string CredentialsFilePath = "credentials.txt";

        public static string CurrentUsername;
        public static string CurrentPassword;

        public SettingsForm()
        {
            InitializeComponent();
            LoadCredentials();
        }

        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            string oldUsername = OldUsernameTextBox.Text.Trim();
            string oldPassword = OldPasswordBox.Password.Trim();
            string newUsername = NewUsernameTextBox.Text.Trim();
            string newPassword = NewPasswordBox.Password.Trim();

            if (string.IsNullOrWhiteSpace(newUsername) || string.IsNullOrWhiteSpace(newPassword))
            {
                MessageBox.Show("New username and password cannot be empty.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (oldUsername == CurrentUsername && oldPassword == CurrentPassword)
            {
                CurrentUsername = newUsername;
                CurrentPassword = newPassword;
                SaveCredentials();

                MessageBox.Show("Credentials updated successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Old credentials are incorrect. Please try again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BackToDashboardButton_Click(object sender, RoutedEventArgs e)
        {
            DashboardWindow dashboardWindow = new DashboardWindow();
            dashboardWindow.Show();
            this.Close();
            //MainWindow mainWindow = new MainWindow();
            //mainWindow.Show();
            //this.Close();
        }

        private void LoadCredentials()
        {
            if (File.Exists(CredentialsFilePath))
            {
                var credentials = File.ReadAllLines(CredentialsFilePath);
                if (credentials.Length == 2)
                {
                    CurrentUsername = credentials[0];
                    CurrentPassword = credentials[1];
                }
                else
                {
                    SetDefaultCredentials();
                }
            }
            else
            {
                SetDefaultCredentials();
            }
        }

        private void SaveCredentials()
        {
            File.WriteAllLines(CredentialsFilePath, new[] { CurrentUsername, CurrentPassword });
        }

        private void SetDefaultCredentials()
        {
            CurrentUsername = "admin";
            CurrentPassword = "admin123";
            SaveCredentials();
        }
    }
}
