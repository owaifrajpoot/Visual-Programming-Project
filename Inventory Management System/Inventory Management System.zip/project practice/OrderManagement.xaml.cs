﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Data.SqlClient;

namespace project_practice
{
    public partial class OrderManagement : Window
    {
        private readonly string connectionString;

        public OrderManagement()
        {
            InitializeComponent();
            connectionString = @"Data Source=DESKTOP-14CFJQK\SQLEXPRESS; Initial Catalog=INVENTORY_MANAGEMENT_SYSTEM; Integrated Security=True; TrustServerCertificate=True";
            LoadPurchaseOrders();
            LoadSalesOrders();
        }

        private void LoadPurchaseOrders()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT PurchaseOrderID, SupplierID, OrderDate, Status, TotalAmount FROM PurchaseOrders";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    PurchaseOrderDataGrid.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading purchase orders: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadSalesOrders()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT SalesOrderID, CustomerName, OrderDate, Status, TotalAmount FROM SalesOrders";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    SalesOrderDataGrid.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading sales orders: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddPurchaseOrderButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO PurchaseOrders (SupplierID, Status, TotalAmount) VALUES (@SupplierID, @Status, @TotalAmount)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@SupplierID", int.Parse(SupplierIDTextBox.Text));
                    command.Parameters.AddWithValue("@Status", (PurchaseStatusComboBox.SelectedItem as ComboBoxItem)?.Content.ToString());
                    command.Parameters.AddWithValue("@TotalAmount", decimal.Parse(PurchaseTotalAmountTextBox.Text));
                    command.ExecuteNonQuery();
                    MessageBox.Show("Purchase order added successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadPurchaseOrders();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding purchase order: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void AddSalesOrderButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO SalesOrders (CustomerName, Status, TotalAmount) VALUES (@CustomerName, @Status, @TotalAmount)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@CustomerName", CustomerNameTextBox.Text);
                    command.Parameters.AddWithValue("@Status", (SalesStatusComboBox.SelectedItem as ComboBoxItem)?.Content.ToString());
                    command.Parameters.AddWithValue("@TotalAmount", decimal.Parse(SalesTotalAmountTextBox.Text));
                    command.ExecuteNonQuery();
                    MessageBox.Show("Sales order added successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    LoadSalesOrders();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding sales order: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void RefreshPurchaseOrdersButton_Click(object sender, RoutedEventArgs e)
        {
            LoadPurchaseOrders();
        }

        private void RefreshSalesOrdersButton_Click(object sender, RoutedEventArgs e)
        {
            LoadSalesOrders();
        }

        private void ReorderAlertsButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Reorder alert functionality will be implemented here.", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void GoToDashboardButton_Click(object sender, RoutedEventArgs e)
        {
            DashboardWindow dashboard = new DashboardWindow();
            dashboard.Show();
            this.Close();
        }
    }
}
