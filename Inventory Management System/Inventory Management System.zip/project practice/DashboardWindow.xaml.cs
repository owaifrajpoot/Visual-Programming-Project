﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows;
using LiveCharts;
using LiveCharts.Wpf;

namespace project_practice
{
    public partial class DashboardWindow : Window
    {
        private readonly string connectionString;

        // Properties for chart data
        public ChartValues<int> SalesValues { get; set; }
        public ChartValues<int> CountryValues { get; set; }

        public DashboardWindow()
        {
            InitializeComponent();
            connectionString = @"Data Source=DESKTOP-14CFJQK\SQLEXPRESS; Initial Catalog=INVENTORY_MANAGEMENT_SYSTEM; Integrated Security=True; TrustServerCertificate=True";
            LoadDashboardData();
        }

        private void LoadDashboardData()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Load Low Stock Products
                    string lowStockQuery = "SELECT Name, SKU, Quantity FROM Products WHERE Quantity < 10";
                    SqlDataAdapter lowStockAdapter = new SqlDataAdapter(lowStockQuery, connection);
                    DataTable lowStockTable = new DataTable();
                    lowStockAdapter.Fill(lowStockTable);
                    LowStockDataGrid.ItemsSource = lowStockTable.DefaultView;

                    // Mock data for graphs (replace with database queries as needed)
                    SalesValues = new ChartValues<int> { 500, 700, 850, 300, 400 }; // Mock Total Sales data
                    CountryValues = new ChartValues<int> { 30, 70 }; // Mock Country Redistribution data

                    // Bind chart data to the DataContext
                    DataContext = this;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading dashboard data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // Navigation buttons remain the same

        private void OpenProductForm_Click(object sender, RoutedEventArgs e)
        {
            ProductForm productForm = new ProductForm();
            productForm.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            UserManagement userManagement = new UserManagement();
            userManagement.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            InventoryTracking inventoryTracking = new InventoryTracking();
            inventoryTracking.Show();
            this.Close();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            OrderManagement orderManagement = new OrderManagement();
            orderManagement.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            SupplierManagement supplierManagement = new SupplierManagement();
            supplierManagement.Show();
            this.Close();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            SettingsForm settingsForm = new SettingsForm();
            settingsForm.Show();
            this.Close();
        }
    }
}
