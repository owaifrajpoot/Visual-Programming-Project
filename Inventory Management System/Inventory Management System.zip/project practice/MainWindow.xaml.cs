﻿using System.Windows;

namespace project_practice
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            LoadCredentials();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string enteredUsername = usernameTextBox.Text.Trim();
            string enteredPassword = passwordBox.Password.Trim();

            if (enteredUsername == SettingsForm.CurrentUsername && enteredPassword == SettingsForm.CurrentPassword)
            {
                DashboardWindow dashboardWindow = new DashboardWindow();
                dashboardWindow.Show();
                this.Close();
                //SettingsForm settingsForm = new SettingsForm();
                //settingsForm.Show();
                //this.Close();
            }
            else
            {
                MessageBox.Show("Invalid username or password. Please try again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void LoadCredentials()
        {
            SettingsForm settingsForm = new SettingsForm();
        }
    }
}
